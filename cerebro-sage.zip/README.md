Another wordpress themes using sage as base template

## installation for test purpose
* copy themes to wordpress themes folder.
* run npm install > bower install > gulp.
* if on development process run gulp watch
* import data test from tools > import > wordpress
* open wp dashboard, edit themes
* open costumize menu
* add 2 menu set: header menu, footer menu
* at customize, set main header in menu option
* for footer can be added at widget part, add custom menu, add text for copyright
* set frontpage as static page

## adding share button support
* install JETPACK plugin
* activate shared buttons
* edit functions and css to change it position on post

## adding popular post support
* install plugin WordPress Popular Posts on news single page

## allowing registration
* go to setting > tick membership > set new user default role
* add custom page for login
* add custom page for registration
* adding plugin: WP User Avatar 2.0.3

--------
aDMIN:rahasia
