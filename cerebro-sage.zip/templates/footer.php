<footer class="footer">
  <div class="container-fluid">
    <?php
    	if ( is_active_sidebar('sidebar-footer')) {
    		dynamic_sidebar('sidebar-footer');
    	} 
	 ?>
  </div>
</footer>
